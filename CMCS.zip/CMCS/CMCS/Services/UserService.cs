﻿namespace CMCS.Services
{
    public class UserService
    {
    }
}
